package com.jeefw.model.sys.param;

import core.support.ExtJSBaseParameter;

/**
 * 角色权限的参数类
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public class RoleAuthorityParameter extends ExtJSBaseParameter {

	private static final long serialVersionUID = -2372512905816639549L;

}
