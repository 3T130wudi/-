package com.jeefw.service.sys;

import com.jeefw.model.sys.Mail;

import core.service.Service;

/**
 * 邮件的业务逻辑层的接口
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public interface MailService extends Service<Mail> {

}
