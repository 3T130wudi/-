package com.jeefw.core;

/**
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public interface Constant {

	public static final String SESSION_SYS_USER = "SESSION_SYS_USER";

	public static final String JEEFW_DATA_SOURCE_BEAN_ID = "jeefwDataSource";

}
