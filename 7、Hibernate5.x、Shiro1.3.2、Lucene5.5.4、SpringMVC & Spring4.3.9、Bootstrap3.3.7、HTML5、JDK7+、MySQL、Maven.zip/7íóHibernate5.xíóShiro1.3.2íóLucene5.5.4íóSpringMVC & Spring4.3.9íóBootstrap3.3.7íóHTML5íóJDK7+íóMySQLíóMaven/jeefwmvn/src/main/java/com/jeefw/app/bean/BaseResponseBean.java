package com.jeefw.app.bean;

/**
 * APP接口的实体Bean的响应端的父类
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public class BaseResponseBean {

}
