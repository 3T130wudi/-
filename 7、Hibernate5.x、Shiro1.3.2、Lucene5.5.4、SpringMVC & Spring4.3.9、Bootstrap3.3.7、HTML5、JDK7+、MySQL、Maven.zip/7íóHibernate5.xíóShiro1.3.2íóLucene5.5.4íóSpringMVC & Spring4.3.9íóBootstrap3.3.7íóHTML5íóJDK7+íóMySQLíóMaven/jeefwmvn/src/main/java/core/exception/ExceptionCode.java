package core.exception;

/**
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public interface ExceptionCode {

	public String getCode();

}
