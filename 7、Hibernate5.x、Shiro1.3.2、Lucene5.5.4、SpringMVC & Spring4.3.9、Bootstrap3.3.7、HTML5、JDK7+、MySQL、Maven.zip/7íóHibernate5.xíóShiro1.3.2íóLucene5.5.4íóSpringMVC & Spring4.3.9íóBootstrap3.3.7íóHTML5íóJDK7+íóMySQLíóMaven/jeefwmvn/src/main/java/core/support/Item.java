package core.support;

/**
 * @框架唯一的升级和技术支持地址：http://shop111863449.taobao.com
 */
public class Item {

	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
